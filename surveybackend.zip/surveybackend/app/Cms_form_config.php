<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cms_form_config extends Model
{
    //
}
