<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Study_item_access extends Model
{
    //
}
